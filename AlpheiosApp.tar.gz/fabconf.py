# the user to use for the remote commands
user = 'thibault'
# the servers where the commands are executed
hosts = ['127.0.0.1']
# Path where we should install
path = "/home/thibault/alpheios"

# Available hosts for stage and prod
available_hosts = {
    "prod": {
        "user": "thibault",
        "host": ["192.168.43.56"],
        "remote_path": "/home/thibault/alpheios",
        "remote_cache_path": "/home/thibault/.alpheios-prod",
        "remote_pip_cache": "/home/thibault/alpheios/.pip",
        "remote_conf_path": "/home/thibault/alpheios/.conf",
        "remote_data_path": "/home/thibault/alpheios/.data",
        "remote_venv_path": "/home/thibault/alpheios/.prodvenv",
        "remote_wsgi_path": "/home/thibault/alpheios/prod.wsgi"
    },
    "stage": {
        "user": "thibault",
        "host": ["192.168.43.56"],
        "remote_path": "/home/thibault/alpheios",
        "remote_cache_path": "/home/thibault/.alpheios-stage",
        "remote_pip_cache": "/home/thibault/alpheios/.pip",
        "remote_conf_path": "/home/thibault/alpheios/.conf",
        "remote_data_path": "/home/thibault/alpheios/.data",
        "remote_venv_path": "/home/thibault/alpheios/.stagevenv",
        "remote_wsgi_path": "/home/thibault/alpheios/stage.wsgi"
    }
}
