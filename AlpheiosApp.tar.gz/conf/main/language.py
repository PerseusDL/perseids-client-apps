# -*- coding: utf-8 -*-

language = {
    "available" : {
        "en": "English",
        "fr": "Français"
    }
}