# -*- coding: utf-8 -*-

cts = {
    "version" : 3,
    "endpoint" : "http://sosol.perseids.org/exist/rest/db/xq/CTS.xq?",
    "getCapabilities" : "http://sosol.perseids.org/sosol/cts/getcapabilities/"
}