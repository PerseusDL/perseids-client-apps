# -*- coding: utf-8 -*-

session = {
    "sessionTokenName" : "csrftoken",
    "sessionHeaderName" : "X-CSRF-Token",
    "pingUrl" : "http://sosol.perseids.org/sosol/dmm_api/ping"

}